# blacktech
BlackTech class for Security
